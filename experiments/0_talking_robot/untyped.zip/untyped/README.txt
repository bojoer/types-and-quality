Please go to http://goo.gl/lXC8o6 for instructions.

package carlosgsouza.vinylshop.view;

import java.util.List;

import carlosgsouza.derails.View;
import carlosgsouza.vinylshop.model.Vinyl;

class DeleteVinylView extends View {

	public DeleteVinylView() {
		items.add("Vinyl deleted");
	}

}

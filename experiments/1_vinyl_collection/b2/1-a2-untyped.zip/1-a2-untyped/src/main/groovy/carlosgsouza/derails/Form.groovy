package carlosgsouza.derails;


public class Form {
	public String title
	public Map<String, String> fields = new HashMap<String, String>();
	public List<String> fieldName = new ArrayList<String>();
}

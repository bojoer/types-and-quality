package carlosgsouza.vinylshop.view;

import java.util.List;

import carlosgsouza.derails.View;
import carlosgsouza.vinylshop.model.Vinyl;

class ShowVinylView extends View {

	public ShowVinylView(vinyl) {
		items.add(vinyl);
	}

}
